#pragma once

#include <cstddef>

constexpr size_t kAlphabetSize = 256;